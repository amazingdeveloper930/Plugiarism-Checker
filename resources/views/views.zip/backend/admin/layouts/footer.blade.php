<footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href=" {{ route('home')}} ">
                  Home
                </a>
              </li>
              <li>
                <a href=" {{ route('pages.about')}} ">
                  About Us
                </a>
              </li>
              <li>
                <a href=" {{ route('pages.blog')}} ">
                  Blog
                </a>
              </li>
              <li>
                <a href=" {{ route('service')}} ">
                  Service
                </a>
              </li>
              <li>
                <a href=" {{ route('industry')}} ">
                  Industry
                </a>
              </li>
              <li>
                <a href=" {{ route('pages.contact')}} ">
                  Contact Us
                </a>
              </li>
              
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a  target="_blank">Eastern Star</a> for a better web.
          </div>
        </div>
      </footer>