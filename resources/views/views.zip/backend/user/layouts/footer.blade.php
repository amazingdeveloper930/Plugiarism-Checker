<footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href=" {{ route('home')}} ">
                  The checker
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            Copyright &copy; 
            <script>
              document.write(new Date().getFullYear())
            </script> Plagiarismchecker All Right Reserved
          </div>
        </div>
      </footer>