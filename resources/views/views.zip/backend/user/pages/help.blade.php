@extends('backend.user.layouts.default')
@section('title', 'Plagiarismchecker | Help Tool')
@section('description', "Plagiarismchecker | Help Tool")
@section('content')
    <h1>Help Tool</h1>
@stop