@extends('backend.user.layouts.default')
@section('title', 'Plagiarismchecker | New Plagiarism Search')
@section('description', "Plagiarismchecker |  New Plagiarism Search")
@section('content')
	@include('backend.user.layouts.fileupload')
@stop